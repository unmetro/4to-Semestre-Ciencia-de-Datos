# Clasificación de los SGBD
## Según el modelo
### Jerárquico
### De red
### Relacional
### Orientado a objetos
## Según el número de usuarios
### Monousuario
### Multiusuario
## Según el acceso
### Centralizado
### Distribuido
## Según el ámbito de aplicación
### De propósito general
### De propósito específico
