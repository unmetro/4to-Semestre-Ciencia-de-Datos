def run(numbers: list[int]) -> list[int]:
    # TODO
    return sorted_numbers


# DO NOT TOUCH THE CODE BELOW
if __name__ == '__main__':
    import vendor

    vendor.launch(run)
