

def run(unsorted_items: dict) -> list[tuple]:
    sorted_items = sorted(unsorted_items.items(),key = lambda item: item[1])
    return sorted_items

input_dict = {'a': 'two', 'b': 'one', 'c': 'three'}
output = run(input_dict)
print(output)


# Definimos una función llamada 'run' que toma un diccionario como argumento (unsorted_items)
    # y devuelve una lista de tuplas. La anotación de tipo 'dict' especifica que se espera un diccionario
    # como entrada y 'list[tuple]' especifica que la salida será una lista de tuplas.

# sorted(unsorted_items.items(), key=lambda item: item[1]):
    # 1. `unsorted_items.items()` devuelve los elementos del diccionario como una lista de tuplas.
    # 2. `sorted(..., key=lambda item: item[1])` ordena esta lista de tuplas en función del valor (el segundo elemento de cada tupla).
    #    La expresión `key=lambda item: item[1]` especifica que la clave de ordenación es el segundo elemento de cada tupla.
    #    En este caso, se está ordenando en base a los valores del diccionario ('two', 'one', 'three') en orden ascendente.