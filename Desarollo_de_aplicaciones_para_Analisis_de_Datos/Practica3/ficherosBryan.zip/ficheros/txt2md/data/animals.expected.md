# Clasificación de los animales
## Vertebrados
### Sangre caliente
#### Mamíferos
#### Aves
### Sangre fría
#### Peces
#### Reptiles
#### Anfibios
## Invertebrados
### Poríferos
### Cnidarios
### Platelmintos
### Anélidos
### Moluscos
### Equinodermos
### Artrópodos
#### Crustáceos
#### Arácnidos
#### Insectos
#### Miriápodos
