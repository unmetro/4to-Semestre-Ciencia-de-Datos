def run(n):
    # Generar una lista con los números desde n hasta 1
    conteo_regresivo = list(range(n, 0, -1))

    # Imprimir el resultado
    print(conteo_regresivo)


# llamar a la funcion
run(5)